<?php

define('RANDOM_INDEX_1',0);
define('RANDOM_INDEX_2',0);
define('RANDOM_INDEX_3',0.58);
define('RANDOM_INDEX_4',0.90);
define('RANDOM_INDEX_5',1.12);
define('RANDOM_INDEX_6',1.24);
define('RANDOM_INDEX_7',1.32);
define('RANDOM_INDEX_8',1.41);
define('RANDOM_INDEX_9',1.45);
define('RANDOM_INDEX_10',1.49);
